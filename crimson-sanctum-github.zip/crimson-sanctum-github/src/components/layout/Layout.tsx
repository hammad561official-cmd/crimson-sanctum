import type { ReactNode } from 'react';

interface LayoutProps {
  children: ReactNode;
}

/**
 * Layout
 *
 * Shared page chrome. Deliberately minimal right now — no Header/Footer
 * content yet, since navigation chrome for a one-page cinematic
 * experience is a design decision still pending (persistent "vault seal"
 * indicator vs. traditional navbar).
 *
 * What it DOES own today:
 *  - a skip-to-content link, required for keyboard users to bypass any
 *    future intro/loading sequence
 *  - a skip-intro affordance target (the intro sequence itself will
 *    render its own visible "Skip Intro" control per the accessibility
 *    requirements; this id gives it somewhere to send focus)
 *  - the <main> landmark every route renders into
 */
export function Layout({ children }: LayoutProps) {
  return (
    <>
      <a href="#main-content" className="sr-only-focusable">
        Skip to main content
      </a>
      <main id="main-content">{children}</main>
    </>
  );
}
